import streamlit as st
import requests
import pandas as pd
from requests.exceptions import ConnectTimeout

def redirectToLeader(server_address, message):
    type = message["type"]
    while True:
        if type == "post":
            try:
                response = requests.post(server_address,
                                        json=message,
                                        timeout=1)
            except Exception as e:
                return e
        
        elif type == "get":
            try:
                response = requests.get(server_address,
                                        json=message,
                                        timeout=1)
            except Exception as e:
                return e
            
        if response.status_code == 200 and "payload" in response.json():
            payload = response.json()["payload"]
            if "message" in payload:
                server_address = payload["message"] + "/request"
            else:
                break
        else:
            break
    return response.json()

def red(message):
    server_address = "http://127.0.0.1:5000/request"
    out = redirectToLeader(server_address, message)
    print(out)

    if isinstance(out, ConnectTimeout):
        return -3
    elif isinstance(out, dict):
        if "reason" in out:
            return -1
        elif out.get("code") == "fail":
            return -2
        else:
            return 1
    else:
        return -4
    
    
def register(username, password, email):
    payload = {"key": "register", "username": username, "password": password, "email": email}
    message = {"type": "post", "payload": payload}
    return red(message)

def login(username, password):
    payload = {"key": "login", "username": username, "password": password}
    message = {"type": "get", "payload": payload}
    return red(message)

def add_task(username, task_name, due_date, priority, status, description):
    due_date = str(due_date)
    payload = {"key": "add", "username": username, "task_name": task_name, "due_date": due_date, "priority": priority, "status": status, "description": description}
    message = {"type": "post", "payload": payload}
    return red(message)
    
def view_all_tasks(username):
    payload = {"key": "view", "username": username}
    message = {"type": "get", "payload": payload}
    server_address = "http://127.0.0.1:5000/request"
    out = redirectToLeader(server_address, message)
    print(out)
    return out

def view_only_task_names(username):
    payload = {"key": "view_names", "username": username}
    message = {"type": "get", "payload": payload}
    server_address = "http://127.0.0.1:5000/request"
    out = redirectToLeader(server_address, message)
    print(out)
    return out

def delete_task(task, username):
    payload = {"key": "delete", "task": task, "username": username}
    message = {"type": "post", "payload": payload}
    return red(message)

def get_task(task, username):
    payload = {"key": "get_tasks", "task": task, "username": username}
    message = {"type": "get", "payload": payload}
    server_address = "http://127.0.0.1:5000/request"
    out = redirectToLeader(server_address, message)
    print(out)
    return out

def update(new_task_name, new_priority, new_status, new_description, task_name, priority, status, description, username):
    payload = {"key": "update", "nt": new_task_name, "np": new_priority, "ns": new_status, "nd": new_description, "t": task_name, "p": priority, "s": status, "d": description, "username": username}
    message = {"type": "post", "payload": payload}
    return red(message)

def main():
    st.title('Task Management App')
    # Navbar
    if 'show_login' not in st.session_state:
        st.session_state.show_login = False
    if 'username' not in st.session_state:
        st.session_state.username = None

    menu = ["Login", "Register", "Add", "View", "Edit", "Remove"]
    choice = st.sidebar.selectbox("Menu", menu)

    if choice == "Login":
        st.header('User Login')

        username_login = st.text_input('Username for Login')
        password_login = st.text_input('Password for Login', type='password')

        if st.button('Login'):
            if username_login and password_login:
                if login(username_login, password_login) == 1:
                    st.session_state.show_login = True
                    st.session_state.username = username_login
                    st.success('Logged in successfully')
                elif login(username_login, password_login) == -1:
                    st.error('Invalid username or password')
                else:
                    st.error("server error")
            else:
                st.error('Fill all details')

    elif choice == "Register":
        st.header('User Registration')

        username_reg = st.text_input('Username for Registration')
        password_reg = st.text_input('Password for Registration', type='password')
        email_reg = st.text_input('Email for Registration')

        if st.button('Register'):
            if username_reg and password_reg and email_reg:
                if register(username_reg, password_reg, email_reg):
                    st.session_state.show_login = True
                    st.session_state.username = username_reg  # Use username_reg instead of username_login
                    st.success('User registered successfully')
                elif register(username_reg, password_reg, email_reg) == -1:
                    st.error('Try another username')
                else:
                    st.error("server error")
            else:
                st.error('Fill all details')


    elif choice == "Add":
        if st.session_state.show_login == False:
            st.error('Login or Register')
        else:
            st.subheader("Enter Task Details:")
            col1, col2 = st.columns(2)
            with col1: 
                task_name = st.text_input("Title:")
                due_date = st.date_input("Date:")
            with col2:
                priority = st.selectbox("Priority", ["Low", "Medium", "High"])
                status = st.selectbox("Status", ["Todo", "In Progress", "Done"])
            description = st.text_area("Description:")

            if st.button("Add Task"):
                if task_name and description:
                    if add_task(st.session_state.username, task_name, due_date, priority, status, description):
                        st.success('Task added!')
                else:
                    st.error('Enter task name and description')


    if choice == "View":
        if st.session_state.show_login == False:
            st.error('Login or Register')
        else:
            st.subheader("View created tasks")
            result = view_all_tasks(st.session_state.username)

            if isinstance(result, requests.exceptions.ConnectTimeout):
                st.error('Connection Timeout. Please try again later.')
            else:
                df = pd.DataFrame(result["payload"], columns=['Task ID', 'Task Name', 'Description', 'Due Date', 'Priority', 'Status', 'Created At', 'Updated At'])
                with st.expander("View all Tasks"):
                    st.dataframe(df)


    elif choice == "Edit":
        if st.session_state.show_login == False:
            st.error('Login or Register')
        else:
            st.subheader("Update created tasks")
            result = view_all_tasks(st.session_state.username)
            df = pd.DataFrame(result["payload"], columns=['Task ID', 'Task Name', 'Description', 'Due Date', 'Priority', 'Status', 'Created At', 'Updated At'])
            with st.expander("Current data"):
                st.dataframe(df)

            list_of_tasks = [i[0] for i in view_only_task_names(st.session_state.username)["payload"]]
            selected_task = st.selectbox("Task to Edit", list_of_tasks)
            selected_result = get_task(selected_task, st.session_state.username)["payload"]

            if selected_result:
                task_name = selected_result[0][2]
                description = selected_result[0][3]
                due_date = selected_result[0][4]
                priority = selected_result[0][5]
                status = selected_result[0][6]

                new_task_name = st.text_input("Title:", task_name)
                new_priority = st.selectbox("Priority", ["Low", "Medium", "High"])
                new_status = st.selectbox("Status", ["Todo", "In Progress", "Done"])
                new_description = st.text_area("Description:", description)

                if st.button("Update Dealer"):
                    if update(new_task_name, new_priority, new_status, new_description, task_name, priority, status, description, st.session_state.username):
                        st.success("Successfully updated:: {}".format(task_name))

            new_result = view_all_tasks(st.session_state.username)
            df2 = pd.DataFrame(new_result["payload"], columns=['Task ID', 'Task Name', 'Description', 'Due Date', 'Priority', 'Status', 'Created At', 'Updated At'])
            with st.expander("Updated data"):
                st.dataframe(df2)
                
    elif choice == "Remove":
        if st.session_state.show_login == False:
            st.error('Login or Register')
        else:
            st.subheader("Delete created tasks")
            result = view_all_tasks(st.session_state.username)
            df = pd.DataFrame(result["payload"], columns=['Task ID', 'Task Name', 'Description', 'Due Date', 'Priority', 'Status', 'Created At', 'Updated At'])
            with st.expander("Current data"):
                st.dataframe(df)

            list_of_tasks = [i[0] for i in view_only_task_names(st.session_state.username)["payload"]]
            selected_task = st.selectbox("Task to Delete", list_of_tasks)
            st.warning("Do you want to delete ::{}".format(selected_task))

            if st.button("Delete Dealer"):
                if delete_task(selected_task, st.session_state.username):
                    st.success("Task has been deleted successfully")

            new_result = view_all_tasks(st.session_state.username)
            df2 = pd.DataFrame(new_result["payload"], columns=['Task ID', 'Task Name', 'Description', 'Due Date', 'Priority', 'Status', 'Created At', 'Updated At'])
            with st.expander("Updated data"):
                st.dataframe(df2)
if __name__ == '__main__':
    main()
